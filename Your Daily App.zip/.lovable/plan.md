## Goal
Make the website built here appear on `hireintelligence.in` and `www.hireintelligence.in`, including the newest article and latest page changes.

## Plan
1. **Confirm live URL setup**
   - Check the project’s published URL and custom domain connections.
   - Confirm the custom domains are connected to this same project.

2. **Publish / update the latest version**
   - Run the publish/update action for this project so the current preview version is deployed to the public site.
   - The custom domain should then serve the same content as the latest Lovable app version.

3. **Verify after publishing**
   - Re-check `https://hireintelligence.in` and `https://www.hireintelligence.in` after the deployment finishes.
   - Confirm the newest June 2026 article is visible on the live domain.

## What you may still need to do
If the domain is connected but still shows old content after publishing, you may need to clear browser cache or wait a few minutes for the deployment/CDN cache to refresh. If DNS is the issue, we’ll review the domain setup next.