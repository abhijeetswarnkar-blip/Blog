import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hire Intelligence" },
      { name: "description", content: "Dispatches from the talent intelligence frontier — AI-first executive search and leadership hiring insights by Abhijeet Swarnkar." },
      { property: "og:title", content: "Hire Intelligence" },
      { property: "og:description", content: "Where AI meets the art of hiring right." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/hire.html"
      title="Hire Intelligence"
      style={{ border: 0, width: "100vw", height: "100vh", display: "block" }}
    />
  );
}
